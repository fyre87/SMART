import numpy as np
from pyearth import Earth
import pandas as pd
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import time
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, BaggingRegressor
import os
import warnings

os.chdir("Test Data/")

random_state = 1

lending_club_train = pd.read_csv("Lending_Club_train.csv")
lending_club_test = pd.read_csv("Lending_Club_train.csv")

energy_train = pd.read_csv("ENB2012_data_train.csv")
energy_test = pd.read_csv("ENB2012_data_test.csv")

airfoil_train = pd.read_csv("airfoil_train.csv")
airfoil_test = pd.read_csv("airfoil_test.csv")

bike_train = pd.read_csv("bike_train.csv")
bike_test = pd.read_csv("bike_test.csv")

california_train = pd.read_csv("california_train.csv")
california_test = pd.read_csv("california_test.csv")


def test_function(results_df, train, test, model, model_name, dataset_name):
    X_train = train.drop(['y'], axis = 1)
    y_train = train.y
    X_test = test.drop(['y'], axis = 1)
    y_test = test.y
    
    start_time = time.time()
    model.fit(X_train, y_train)
    print(model.summary())
    mse = mean_squared_error(y_test, model.predict(X_test))
    total_time = (time.time()-start_time)
    results_df.loc[len(results_df)] = [dataset_name, model_name, mse, total_time]
    
    print(results_df)
    return results_df

results_df = pd.DataFrame(columns=['Dataset', 'Model', 'Model MSE', 'Time'])
model = Earth(max_degree = 2, enable_pruning = True, allow_subset = False)
results_df = test_function(results_df, lending_club_train, lending_club_test, model, "MARS", "lending_club")
results_df = test_function(results_df, energy_train, energy_test, model, "MARS", "energy")
results_df = test_function(results_df, airfoil_train, airfoil_test, model, "MARS", "airfoil")
results_df = test_function(results_df, bike_train, bike_test, model, "MARS", "bike")
results_df = test_function(results_df, california_train, california_test, model, "MARS", "california")
results_df.to_csv("MARS real data.csv")


results_df = pd.DataFrame(columns=['Dataset', 'Model', 'Model MSE', 'Time'])
model = Earth(max_degree = 2, enable_pruning = True, allow_subset = True)
results_df = test_function(results_df, lending_club_train, lending_club_test, model, "SMART", "lending_club")
results_df = test_function(results_df, energy_train, energy_test, model, "SMART", "energy")
results_df = test_function(results_df, airfoil_train, airfoil_test, model, "SMART", "airfoil")
results_df = test_function(results_df, bike_train, bike_test, model, "SMART", "bike")
results_df = test_function(results_df, california_train, california_test, model, "SMART", "california")
results_df.to_csv("SMART real data.csv")



