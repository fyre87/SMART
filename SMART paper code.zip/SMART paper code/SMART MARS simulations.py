import numpy as np
from pyearth import Earth
import pandas as pd
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import time
import json
from sklearn.model_selection import train_test_split, KFold, GridSearchCV
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, BaggingRegressor
import os
import warnings
warnings.filterwarnings('ignore')

random_state = 1
os.chdir("Thesis Training/")

rs1_train = pd.read_csv("Synthetic/rs1_train.csv")
rs2_train = pd.read_csv("Synthetic/rs2_train.csv")
rs3_train = pd.read_csv("Synthetic/rs3_train.csv")
rs4_train = pd.read_csv("Synthetic/rs4_train.csv")
rs5_train = pd.read_csv("Synthetic/rs5_train.csv")

rs1_test = pd.read_csv("Synthetic/rs1_test.csv")
rs2_test = pd.read_csv("Synthetic/rs2_test.csv")
rs3_test = pd.read_csv("Synthetic/rs3_test.csv")
rs4_test = pd.read_csv("Synthetic/rs4_test.csv")
rs5_test = pd.read_csv("Synthetic/rs5_test.csv")



def test_function(results_df, train, test, model, model_name, dataset_name):
    X_train = train.drop(['y'], axis = 1)
    y_train = train.y
    X_test = test.drop(['y'], axis = 1)
    y_test = test.y
    
    start_time = time.time()
    model.fit(X_train, y_train)
    mse = mean_squared_error(y_test, model.predict(X_test))
    total_time = (time.time()-start_time)
    results_df.loc[len(results_df)] = [dataset_name, model_name, mse, total_time]
    
    
    print(model.summary())
    print(results_df)
    return results_df

results_df = pd.DataFrame(columns=['Dataset', 'Model', 'Model MSE', 'Time'])
model = Earth(enable_pruning = True, allow_subset = True)
results_df = test_function(results_df, rs1_train, rs1_test, model, "SMART", "rs1_train")
results_df = test_function(results_df, rs2_train, rs2_test, model, "SMART", "rs2_train")
results_df = test_function(results_df, rs3_train, rs3_test, model, "SMART", "rs3_train")
results_df = test_function(results_df, rs4_train, rs4_test, model, "SMART", "rs4_train")
results_df = test_function(results_df, rs5_train, rs5_test, model, "SMART", "rs5_train")
results_df.to_csv("SMART Synthetic results.csv")


results_df = pd.DataFrame(columns=['Dataset', 'Model', 'Model MSE', 'Time'])
model = Earth(enable_pruning = True, allow_subset = False)
results_df = test_function(results_df, rs1_train, rs1_test, model, "MARS", "rs1_train")
results_df = test_function(results_df, rs2_train, rs2_test, model, "MARS", "rs2_train")
results_df = test_function(results_df, rs3_train, rs3_test, model, "MARS", "rs3_train")
results_df = test_function(results_df, rs4_train, rs4_test, model, "MARS", "rs4_train")
results_df = test_function(results_df, rs5_train, rs5_test, model, "MARS", "rs5_train")
results_df.to_csv("MARS Synthetic results.csv")
