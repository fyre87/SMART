import numpy as np
from pyearth import Earth
import pandas as pd
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import time
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, BaggingRegressor
import os
import warnings

warnings.filterwarnings("ignore")


x = np.linspace(0, 6, 200)
x1 = x[x<2]
x2 = x[(x >= 2) & (x < 4)]
x3 = x[x>=4]
y1 = np.sin(np.pi*x1)
y2 = 4*x2
y3 = 0.2*np.exp(x3-2)

np.random.seed(seed = 1)
y = np.concatenate([y1, y2, y3]) + np.random.normal(0, 1, 200)
y_simple = np.concatenate([y1, y2, y3])

X_train = pd.DataFrame(x)
y_train = pd.Series(y)

model = Earth(max_degree = 2, enable_pruning = False, allow_subset = True).fit(X_train, y_train)
model_prune = Earth(max_degree = 2, enable_pruning = True, allow_subset = True).fit(X_train, y_train)
MARS = Earth(max_degree = 2, enable_pruning = True, allow_subset = False).fit(X_train, y_train)

# Tune RF
grid = {
    'max_depth': [6, 8, 10, 12, 14, 16, 18, 20],
}
forest = RandomForestRegressor().fit(X_train, y_train)
forest_search = GridSearchCV(estimator=forest, param_grid=grid, cv=5, scoring = 'neg_mean_squared_error').fit(X_train, y_train)
forest = forest_search.best_estimator_


SMART_predictions = model.predict(X_train)
SMART_predictions_prune = model_prune.predict(X_train)
MARS_predictions = MARS.predict(X_train)
forest_predictions = forest.predict(X_train)

# Plot the true function
plt.figure(figsize=(7,4.2))
plt.plot(x1, y1, linestyle = ':', linewidth = 3, color = 'black', label='True Function')
plt.plot(x2, y2, linestyle = ':', linewidth = 3, color = 'black')
plt.plot(x3, y3, linestyle = ':', linewidth = 3, color = 'black')

print(model.summary())

def plot_trees(y_pred):
    offset = 6/200
    unique_levels = np.unique(y_pred)
    first = True
    for level in unique_levels:
        indexes = np.where(y_pred == level)[0]
        if len(indexes) == 1:
            if first == True:
                # If there's only one point in the level, plot a short line with an offset
                plt.plot([x[indexes[0]], x[indexes[0]]+offset], [level, level], '-', alpha = 0.8, ms=5, color='green', linewidth=3, label='CART')
                first = False
            else:
                plt.plot([x[indexes[0]], x[indexes[0]]+offset], [level, level], '-', alpha = 0.8, ms=5, color='green', linewidth=3)
        else:
            # Plot the line for levels with more than one point
            plt.plot(x[indexes[0]:indexes[-1]+1], y_pred[indexes[0]:indexes[-1]+1], '-', alpha = 0.8, ms=5, color = 'green', linewidth=3)


def plot_subset(y_pred):    
    # Chosen splits by SMART
    tree_splits = [2.0050251256281406, 3.9949748743718594]

    # Adding the start and end of X to ensure all data is covered
    all_splits = [x[0]] + tree_splits + [x[-1]]
    first = True
    # Plot segments
    for i in range(len(all_splits) - 1):
        start, end = all_splits[i], all_splits[i + 1]
        indices = np.where((x >= start) & (x < end))[0]
        if first:
            plt.plot(x[indices], y_pred[indices], '-', alpha = 0.8, ms=5, color = 'blue', linewidth=2, label='Subset Split Predictions')
            first = False
        else:
            plt.plot(x[indices], y_pred[indices], '-', alpha = 0.8, ms=5, color = 'blue', linewidth=2)

# Save the different predictions here for the different figures
plot_subset(SMART_predictions_prune)

# Add legend
plt.legend()
plt.xlabel('X')
plt.ylabel('Y')

plt.grid(True)

print("SMART RMSE pre prune: ", mean_squared_error(y_simple, SMART_predictions)**0.5)
print("SMART RMSE: ", mean_squared_error(y_simple, SMART_predictions_prune)**0.5)
print("MARS RMSE: ", mean_squared_error(y_simple, MARS_predictions)**0.5)
print("Forest RMSE: ", mean_squared_error(y_simple, forest_predictions)**0.5)
plt.savefig("Subset Split.png")
plt.show()

