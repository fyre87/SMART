import numpy as np
from pyearth import Earth
import pandas as pd
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import time
import json
from sklearn.model_selection import train_test_split, KFold, GridSearchCV
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, BaggingRegressor
import os
import warnings

os.chdir("Thesis Training/Test Data/")

random_state = 1


f10_1000_5train = pd.read_csv("Friedman1Sim/10_1000_5train.csv")
f10_5000_5train = pd.read_csv("Friedman1Sim/10_5000_5train.csv")
f30_1000_5train = pd.read_csv("Friedman1Sim/30_1000_5train.csv")
f30_5000_5train = pd.read_csv("Friedman1Sim/30_5000_5train.csv")
f50_1000_5train = pd.read_csv("Friedman1Sim/50_1000_5train.csv")
f50_5000_5train = pd.read_csv("Friedman1Sim/50_5000_5train.csv")
f10_1000_20train = pd.read_csv("Friedman1Sim/10_1000_20train.csv")
f10_5000_20train = pd.read_csv("Friedman1Sim/10_5000_20train.csv")
f30_1000_20train = pd.read_csv("Friedman1Sim/30_1000_20train.csv")
f30_5000_20train = pd.read_csv("Friedman1Sim/30_5000_20train.csv")
f50_1000_20train = pd.read_csv("Friedman1Sim/50_1000_20train.csv")
f50_5000_20train = pd.read_csv("Friedman1Sim/50_5000_20train.csv")

f10_1000_5test = pd.read_csv("Friedman1Sim/10_1000_5test.csv")
f10_5000_5test = pd.read_csv("Friedman1Sim/10_5000_5test.csv")
f30_1000_5test = pd.read_csv("Friedman1Sim/30_1000_5test.csv")
f30_5000_5test = pd.read_csv("Friedman1Sim/30_5000_5test.csv")
f50_1000_5test = pd.read_csv("Friedman1Sim/50_1000_5test.csv")
f50_5000_5test = pd.read_csv("Friedman1Sim/50_5000_5test.csv")
f10_1000_20test = pd.read_csv("Friedman1Sim/10_1000_20test.csv")
f10_5000_20test = pd.read_csv("Friedman1Sim/10_5000_20test.csv")
f30_1000_20test = pd.read_csv("Friedman1Sim/30_1000_20test.csv")
f30_5000_20test = pd.read_csv("Friedman1Sim/30_5000_20test.csv")
f50_1000_20test = pd.read_csv("Friedman1Sim/50_1000_20test.csv")
f50_5000_20test = pd.read_csv("Friedman1Sim/50_5000_20test.csv")

f2_1000_5train = pd.read_csv("Friedman2Sim/1000_5train.csv")
f2_5000_5train = pd.read_csv("Friedman2Sim/5000_5train.csv")
f2_1000_20train = pd.read_csv("Friedman2Sim/1000_20train.csv")
f2_5000_20train = pd.read_csv("Friedman2Sim/5000_20train.csv")
f2_1000_5test = pd.read_csv("Friedman2Sim/1000_5test.csv")
f2_5000_5test = pd.read_csv("Friedman2Sim/5000_5test.csv")
f2_1000_20test = pd.read_csv("Friedman2Sim/1000_20test.csv")
f2_5000_20test = pd.read_csv("Friedman2Sim/5000_20test.csv")

f3_1000_5train = pd.read_csv("Friedman3Sim/1000_5train.csv")
f3_5000_5train = pd.read_csv("Friedman3Sim/5000_5train.csv")
f3_1000_20train = pd.read_csv("Friedman3Sim/1000_20train.csv")
f3_5000_20train = pd.read_csv("Friedman3Sim/5000_20train.csv")
f3_1000_5test = pd.read_csv("Friedman3Sim/1000_5test.csv")
f3_5000_5test = pd.read_csv("Friedman3Sim/5000_5test.csv")
f3_1000_20test = pd.read_csv("Friedman3Sim/1000_20test.csv")
f3_5000_20test = pd.read_csv("Friedman3Sim/5000_20test.csv")

os.chdir("Thesis Training/")
import warnings
warnings.filterwarnings('ignore')

def test_function(results_df, train, test, model, model_name, dataset_name):
    X_train = train.drop(['y'], axis = 1)
    y_train = train.y
    X_test = test.drop(['y'], axis = 1)
    y_test = test.y
    
    start_time = time.time()
    model.fit(X_train, y_train)
    mse = mean_squared_error(y_test, model.predict(X_test))
    total_time = (time.time()-start_time)
    results_df.loc[len(results_df)] = [dataset_name, model_name, mse, total_time]
    
    print(results_df)
    return results_df

# Test SMART
results_df = pd.DataFrame(columns=['Dataset', 'Model', 'Model MSE', 'Time'])
model = Earth(enable_pruning = True, allow_subset = True, max_degree = 2)
results_df = test_function(results_df, f10_1000_5train, f10_1000_5test, model, "SMART", "f10_1000_5train")
results_df = test_function(results_df, f10_5000_5train, f10_5000_5test, model, "SMART", "f10_5000_5train")
results_df = test_function(results_df, f30_1000_5train, f30_1000_5test, model, "SMART", "f30_1000_5train")
results_df = test_function(results_df, f30_5000_5train, f30_5000_5test, model, "SMART", "f30_5000_5train")
results_df = test_function(results_df, f50_1000_5train, f50_1000_5test, model, "SMART", "f50_1000_5train")
results_df = test_function(results_df, f50_5000_5train, f50_5000_5test, model, "SMART", "f50_5000_5train")
results_df = test_function(results_df, f10_1000_20train, f10_1000_20test, model, "SMART", "f10_1000_20train")
results_df = test_function(results_df, f10_5000_20train, f10_5000_20test, model, "SMART", "f10_5000_20train")
results_df = test_function(results_df, f30_1000_20train, f30_1000_20test, model, "SMART", "f30_1000_20train")
results_df = test_function(results_df, f30_5000_20train, f30_5000_20test, model, "SMART", "f30_5000_20train")
results_df = test_function(results_df, f50_1000_20train, f50_1000_20test, model, "SMART", "f50_1000_20train")
results_df = test_function(results_df, f50_5000_20train, f50_5000_20test, model, "SMART", "f50_5000_20train")
results_df = test_function(results_df, f2_1000_5train, f2_1000_5test, model, "SMART", "f2_1000_5train")
results_df = test_function(results_df, f2_5000_5train, f2_5000_5test, model, "SMART", "f2_5000_5train")
results_df = test_function(results_df, f2_1000_20train, f2_1000_20test, model, "SMART", "f2_1000_20train")
results_df = test_function(results_df, f2_5000_20train, f2_5000_20test, model, "SMART", "f2_5000_20train")
results_df = test_function(results_df, f3_1000_5train, f3_1000_5test, model, "SMART", "f3_1000_5train")
results_df = test_function(results_df, f3_5000_5train, f3_5000_5test, model, "SMART", "f3_5000_5train")
results_df = test_function(results_df, f3_1000_20train, f3_1000_20test, model, "SMART", "f3_1000_20train")
results_df = test_function(results_df, f3_5000_20train, f3_5000_20test, model, "SMART", "f3_5000_20train")
results_df.to_csv("SMART Friedman results.csv")


# Test MARS
results_df = pd.DataFrame(columns=['Dataset', 'Model', 'Model MSE', 'Time'])
model = Earth(enable_pruning = True, allow_subset = False, max_degree = 2)
results_df = test_function(results_df, f10_1000_5train, f10_1000_5test, model, "MARS", "f10_1000_5train")
results_df = test_function(results_df, f10_5000_5train, f10_5000_5test, model, "MARS", "f10_5000_5train")
results_df = test_function(results_df, f30_1000_5train, f30_1000_5test, model, "MARS", "f30_1000_5train")
results_df = test_function(results_df, f30_5000_5train, f30_5000_5test, model, "MARS", "f30_5000_5train")
results_df = test_function(results_df, f50_1000_5train, f50_1000_5test, model, "MARS", "f50_1000_5train")
results_df = test_function(results_df, f50_5000_5train, f50_5000_5test, model, "MARS", "f50_5000_5train")
results_df = test_function(results_df, f10_1000_20train, f10_1000_20test, model, "MARS", "f10_1000_20train")
results_df = test_function(results_df, f10_5000_20train, f10_5000_20test, model, "MARS", "f10_5000_20train")
results_df = test_function(results_df, f30_1000_20train, f30_1000_20test, model, "MARS", "f30_1000_20train")
results_df = test_function(results_df, f30_5000_20train, f30_5000_20test, model, "MARS", "f30_5000_20train")
results_df = test_function(results_df, f50_1000_20train, f50_1000_20test, model, "MARS", "f50_1000_20train")
results_df = test_function(results_df, f50_5000_20train, f50_5000_20test, model, "MARS", "f50_5000_20train")
results_df = test_function(results_df, f2_1000_5train, f2_1000_5test, model, "MARS", "f2_1000_5train")
results_df = test_function(results_df, f2_5000_5train, f2_5000_5test, model, "MARS", "f2_5000_5train")
results_df = test_function(results_df, f2_1000_20train, f2_1000_20test, model, "MARS", "f2_1000_20train")
results_df = test_function(results_df, f2_5000_20train, f2_5000_20test, model, "MARS", "f2_5000_20train")
results_df = test_function(results_df, f3_1000_5train, f3_1000_5test, model, "MARS", "f3_1000_5train")
results_df = test_function(results_df, f3_5000_5train, f3_5000_5test, model, "MARS", "f3_5000_5train")
results_df = test_function(results_df, f3_1000_20train, f3_1000_20test, model, "MARS", "f3_1000_20train")
results_df = test_function(results_df, f3_5000_20train, f3_5000_20test, model, "MARS", "f3_5000_20train")
results_df.to_csv("MARS Friedman results.csv")


